package rma.lv1

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.firestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import rma.lv1.ui.theme.LV1Theme
import java.security.AllPermission
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener import android.hardware.SensorManager
import android.widget.Toast
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.google.firebase.auth.FirebaseAuth
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import rma.lv1.WeatherResponse as WeatherResponse

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            val sensorManager = (LocalContext.current.getSystemService(Context.SENSOR_SERVICE) as SensorManager)

            NavHost(navController = navController, startDestination = "login_screen") {
                composable("login_screen") {
                    LoginRegisterScreen(navController = navController)
                }
                composable("main_screen") {
                    MainScreen(navController = navController)
                }
                composable("step_counter") {
                    StepCounter(navController = navController, sensorManager = sensorManager)
                }
            }
        }
    }
}

@Composable
fun MainScreen(navController: NavController) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        BackgroundImage(modifier = Modifier.fillMaxSize())
        UserPreview(name = "Matej Kupresak", visina = 1.85f, tezina = 95f, modifier = Modifier.fillMaxSize())

        Button(
            onClick = {
                navController.navigate("step_counter")
            },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ){
            Text(text = "Step Counter")
        }
    }
}

@Composable
fun StepCounter(navController: NavController, sensorManager: SensorManager) {
    val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    var steps by remember { mutableStateOf(0) }
    var isSensorRegistered by remember { mutableStateOf(false) }

    LaunchedEffect(key1 = true) {
        if (!isSensorRegistered) {
            val sensorEventListener = object : SensorEventListener {
                var previousY: Float = 0f
                var previousZ: Float = 0f
                var previousX: Float = 0f

                override fun onSensorChanged(event: SensorEvent?) {
                    event?.let {
                        val x = it.values[0]
                        val y = it.values[1]
                        val z = it.values[2]

                        if (previousX != null && previousY != null && previousZ != null) {
                            val squareX = previousX * previousX
                            val squareY = previousY * previousY
                            val squareZ = previousZ * previousZ

                            val threshold = kotlin.math.sqrt(squareX + squareY + squareZ)

                            if (threshold > 13) {
                                steps++
                            }
                        }

                        previousX = x
                        previousY = y
                        previousZ = z
                    }
                }

                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }

            sensorManager.registerListener(
                sensorEventListener,
                sensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
            isSensorRegistered = true
        }
    }

    StepCounterUI(navController, steps)
}

@Composable
fun StepCounterUI(navController: NavController, steps: Int) {
    Box(modifier = Modifier.fillMaxSize()) {
        BackgroundImage(modifier = Modifier.fillMaxSize())

        Column {
            Text(
                text = "Step Count: $steps",
                fontSize = 20.sp
            )
        }

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Text("Back to User Info")
        }

        Button(
            onClick = { saveStepsToFirebase(steps) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Text("Save Steps")
        }
    }
}

fun saveStepsToFirebase(steps: Int) {
    val db = FirebaseFirestore.getInstance()
    val docRef = db.collection("BMI").document("IAq6tcNxx485ssq8WVUh")
    docRef.update("koraci", steps)
}

@Composable
fun UserPreview(name: String, visina: Float, tezina: Float, modifier: Modifier = Modifier) {
    val db = FirebaseFirestore.getInstance()

    var bmi by remember {
        mutableStateOf(tezina / (visina * visina))
    }
    var formattedBmi by remember {
        mutableStateOf(String.format("%.2f", bmi))
    }
    var newTezina by remember { mutableStateOf(0f) }
    var newVisina by remember { mutableStateOf(0f) }

    Text(
        text = "Pozdrav $name!",
        fontSize = 20.sp,
        lineHeight = 56.sp,
        modifier= Modifier
            .padding(top = 8.dp)
            .padding(start = 10.dp)
    )

    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Text(
            text = "Tvoj BMI je:",
            fontSize = 55.sp,
            lineHeight = 61.sp,
            textAlign = TextAlign.Center,
            )

        TextField(
            value = newTezina.toString(),
            onValueChange = { newTezina = it.toFloatOrNull() ?: 0f },
            label = { Text("Nova tezina:") },
            modifier = Modifier.fillMaxWidth(0.8f)
        )

        TextField(
            value = newVisina.toString(),
            onValueChange = { newVisina = it.toFloatOrNull() ?: 0f },
            label = { Text("Nova tezina:") },
            modifier = Modifier.fillMaxWidth(0.8f)
        )

        Button(
            onClick = {
                val docRef = db.collection("BMI").document("IAq6tcNxx485ssq8WVUh")
                docRef.update("tezina", newTezina)
                docRef.update("visina", newVisina)
                docRef.get()
                    .addOnSuccessListener { document ->
                        val tezina = document.getDouble("tezina")?.toFloat() ?: 0f
                        val visina = document.getDouble("visina")?.toFloat() ?: 0f
                        bmi = tezina / (visina * visina)
                        formattedBmi = String.format("%.2f", bmi)
                    }
                    .addOnFailureListener { e ->
                        Log.e("MainActivity", "Error updating Tezina: $e")
                    }
            }
        ) {
            Text("Ažuriraj Podatke")
        }

        Text(
            text = formattedBmi,
            fontSize = 70.sp,
            lineHeight = 72.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
fun LoginRegisterScreen(navController: NavController) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
    verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = email,
            onValueChange = { email = it }, label = { Text("Email") }
        )
        Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { signIn(context, email, password, navController) }) {
            Text("Login")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { register(context, email, password) }) {
            Text("Register")
        }
    }
}
private fun signIn(context: Context, email: String, password: String, navController: NavController) {
    FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
        .addOnCompleteListener { task -> if (task.isSuccessful) {
            Toast.makeText(context, "Logged in successfully", Toast.LENGTH_SHORT).show()
            navController.navigate("main_screen")
        } else {
            Toast.makeText(context, "Login failed", Toast.LENGTH_SHORT).show()
        }
        }
}

private fun register(context: Context, email: String, password: String) { FirebaseAuth.getInstance().createUserWithEmailAndPassword(email,
    password)
    .addOnCompleteListener { task ->
        if (task.isSuccessful) {
            Toast.makeText(context, "Registered successfully",
                Toast.LENGTH_SHORT).show() } else {
            Toast.makeText(context, "Registration failed", Toast.LENGTH_SHORT).show()
        }
    }
}

data class WeatherResponse(
    val main: Main
)

data class Main(
    val temp: Float,
    val feels_like: Float,
    val temp_min: Float,
    val temp_max: Float,
    val pressure: Int,
    val humidity: Int
)

interface WeatherApiService {
    @GET("weather")
    fun getWeather(
        @Query("lat") latitude: Double,
        @Query("lon") longitude: Double,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): Call<WeatherResponse>
}

private fun fetchWeatherInformation() {
    val retrofit = Retrofit.Builder()
        .baseUrl("https://api.openweathermap.org/data/2.5/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val service = retrofit.create(WeatherApiService::class.java)

    val call = service.getWeather(
        latitude = 45.55111,
        longitude = 18.69389,
        apiKey = "d77ff22feb61febf7fdc4bf7dfa79ca8"
    )

    call.enqueue(object : Callback<WeatherResponse> {
        override fun onResponse(call: Call<WeatherResponse>, response: Response<WeatherResponse>) {
            if (response.isSuccessful) {
                val weatherResponse = response.body()
                if (weatherResponse != null) {
                    val temperature = weatherResponse.main.temp
                    Log.d("Weather", "Current temperature: $temperature°C")
                }
            } else {
                Log.e("Weather", "Response unsuccessful: ${response.errorBody()?.string()}")
            }
        }

        override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
            Log.e("Weather", "Failed to fetch weather information", t)
        }
    })
}

@Composable
fun BackgroundImage(modifier: Modifier) {
    Box (modifier){ Image(
        painter = painterResource(id = R.drawable.fitness),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        alpha = 0.1F
    )
    }
}
@Preview(showBackground = false)
@Composable
fun UserPreview() {
    LV1Theme {
        BackgroundImage(modifier = Modifier)
    }
}